# evonix Hissab (evonix Technologies)

Enterprise Financial Accounting, UAE VAT 5% Compliance, Invoicing, Inventory & ERP Suite.

## 🚀 چلانے کا طریقہ (How to Run on Windows / Mac / Linux)

### طریقہ نمبر 1 (Windows کے لیے - سب سے آسان):
1. اس زپ فائل (ZIP) کو کسی بھی فولڈر میں Extract (ان زپ) کریں۔
2. فولڈر میں موجود `Run_Windows.bat` پر ڈبل کلک کریں۔
3. سسٹم خودکار طریقے سے تمام ضروری پیکجز انسٹال کر کے پورٹل کو اسٹارٹ کر دے گا۔
4. اپنا براؤزر کھولیں اور جائیں: `http://localhost:3000`

---

### طریقہ نمبر 2 (Manual Terminal / Command Prompt):
1. اس فولڈر میں ٹرمینل یا Command Prompt اوپن کریں۔
2. یہ کمانڈ چلائیں:
   ```bash
   npm install
   ```
3. انسٹال ہونے کے بعد یہ کمانڈ چلائیں:
   ```bash
   npm run dev
   ```
4. براؤزر میں `http://localhost:3000` اوپن کریں اور ایپ چیک کریں۔

---

### 📋 سسٹم کی معلومات (System Info):
- **Portal Name:** evonix Hissab
- **Company Name:** evonix Technologies
- **Standard Currency:** AED (United Arab Emirates Dirham)
- **Taxation:** UAE FTA 5% VAT & Corporate Tax Ready
- **Default Login:** Hissabpro1@gmail.com (Password: 123456 یا جو آپ نے پاس ورڈ سیٹ کیا ہو)
