#!/usr/bin/env bash
set -e
echo '===================================================='
echo '          evonix Hissab - evonix Technologies'
echo '   Enterprise Financial Accounting & ERP System'
echo '===================================================='
echo ''
echo '[1/2] Checking and installing dependencies...'
npm install
echo ''
echo '[2/2] Launching application on http://localhost:3000 ...'
echo 'Open your browser at: http://localhost:3000'
echo 'Press Ctrl+C to stop the server.'
echo '===================================================='
npm run dev
