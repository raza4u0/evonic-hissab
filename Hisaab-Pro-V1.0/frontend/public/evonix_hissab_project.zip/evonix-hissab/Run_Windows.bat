@echo off
title evonix Hissab - Accounting & ERP Suite
echo ====================================================
echo           evonix Hissab - evonix Technologies
echo    Enterprise Financial Accounting & ERP System
echo ====================================================
echo.
echo [1/2] Checking and installing dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] npm install failed. Please make sure Node.js is installed.
    pause
    exit /b %errorlevel%
)
echo.
echo [2/2] Launching application on http://localhost:3000 ...
echo Open your browser at: http://localhost:3000
echo Press Ctrl+C in this window to stop the server.
echo ====================================================
call npm run dev
pause
